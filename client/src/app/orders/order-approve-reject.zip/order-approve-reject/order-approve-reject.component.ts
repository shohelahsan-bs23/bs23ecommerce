import { Component, OnInit } from '@angular/core';
import { IOrder } from 'src/app/shared/models/order';
import { OrdersService } from '../orders.service';
import { SelectionModel } from '@angular/cdk/collections';


@Component({
  selector: 'app-order-approve-reject',
  templateUrl: './order-approve-reject.component.html',
  styleUrls: ['./order-approve-reject.component.scss']
})
export class OrderApproveRejectComponent implements OnInit {
  orders: IOrder[];
  orderIds: number[] = [];

  constructor(private ordersService: OrdersService) { }

  ngOnInit() {
    this.getOrders();
  }

  getOrders() {
    this.ordersService.getOrdersForUser().subscribe((orders: IOrder[]) => {
      this.orders = orders;
    }, error => {
      console.log(error);
    });
  }

  

  checkAllCheckBox(ev) {
		
	}

	isAllCheckBoxChecked() {
		
	}

  rowCheck(){
    
    
  }

  approve(orderids: number[]){
    console.log(orderids,'approve');
  }

  reject(orderids: number[]){
    console.log(orderids,'reject');
  }

}
